 //   console.log('Image URLs:', imageUrls);
    //   console.log('Titles', productTitles);
    //   console.log('Prices', prices);
    //   console.log('Product Urls', productUrls);